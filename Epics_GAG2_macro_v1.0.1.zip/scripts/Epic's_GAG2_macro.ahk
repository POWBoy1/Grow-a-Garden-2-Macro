﻿#Requires AutoHotkey v2.0
#SingleInstance Force
#Warn VarUnset, Off
SetWorkingDir A_ScriptDir . "\.."
KeyDelay := 40

Setkeydelay KeyDelay

GetRobloxClientPos()
pToken := Gdip_Startup()
bitmaps := Map()
bitmaps.CaseSense := 0
currentWalk := {pid:"", name:""} ; stores "pid" (script process ID) and "name" (pattern/movement name)
CoordMode "Mouse", "Screen"
CoordMode "Pixel", "Screen"
SendMode "Event"

WKey:="sc011" ; w
AKey:="sc01e" ; a
SKey:="sc01f" ; s
Dkey:="sc020" ; d


RotLeft := "vkBC" ; ,
RotRight := "vkBE" ; .
RotUp := "sc149" ; PgUp
RotDown := "sc151" ; PgDn
ZoomIn := "sc017" ; i
ZoomOut := "sc018" ; o
Ekey := "sc012" ; e
Rkey := "sc013" ; r
Lkey := "sc026" ; l
EscKey := "sc001" ; Esc
EnterKey := "sc01c" ; Enter
SpaceKey := "sc039" ; Space
SlashKey := "vk6F" ; /
SC_LShift:="sc02a" ; LShift



#Include "%A_ScriptDir%"
#include ..\lib\

#Include ComVar.ahk
#Include DiscordWebhook.ahk
#Include FormData.ahk
#Include Gdip_All.ahk
#include Gdip_ImageSearch.ahk
#include json.ahk
#Include OCR.ahk
#Include Promise.ahk
#Include roblox.ahk
#Include WebView2.ahk
#Include WebViewToo.ahk

#Include ..\images\
#include bitmaps.ahk
#include ..\scripts\

#Include gui.ahk
#Include timers.ahk




;@Ahk2Exe-AddResource Gui\index.html, Gui\index.html
;@Ahk2Exe-AddResource Gui\script.js, Gui\script.js
;@Ahk2Exe-AddResource Gui\style.css, Gui\style.css
;@Ahk2Exe-AddResource ..\Lib\32bit\WebView2Loader.dll, 32bit\WebView2Loader.dll
;@Ahk2Exe-AddResource ..\Lib\64bit\WebView2Loader.dll, 64bit\WebView2Loader.dll


HyperSleep(ms) {
    static freq := (DllCall("QueryPerformanceFrequency", "Int64*", &f := 0), f)
    DllCall("QueryPerformanceCounter", "Int64*", &begin := 0)
    current := 0, finish := begin + ms * freq / 1000
    while (current < finish) {
        if ((finish - current) > 30000) {
            DllCall("Winmm.dll\timeBeginPeriod", "UInt", 1)
            DllCall("Sleep", "UInt", 1)
            DllCall("Winmm.dll\timeEndPeriod", "UInt", 1)
        }
        DllCall("QueryPerformanceCounter", "Int64*", &current)
    }
}



ScrollDown(amount := 1) {
    BaseHeight := 1080

    ; Scale factor (based mostly on height, since scroll is vertical)
    Scale := WindowHeight / BaseHeight

    AdjustedAmount := Round(-amount * 120 * Scale)

    DllCall("user32.dll\mouse_event"
        , "UInt", 0x0800   ; MOUSEEVENTF_WHEEL
        , "UInt", 0
        , "UInt", 0
        , "UInt", AdjustedAmount
        , "UPtr", 0)
}


CheckSetting(section,key){
    if (IniRead(settingsFile, section, key) == 1){
        return true
    }
    return false
}


relativeMouseMove(relx, rely) {
    hwnd := GetRobloxHWND()
    GetRobloxClientPos(hwnd)
    moveX := windowX + Round(relx * windowWidth)
    moveY := windowY + Round(rely * windowHeight)
    MouseMove(moveX,moveY)
}




Walk(studs, MoveKey1, MoveKey2:=0) {
	Send "{" MoveKey1  " down}" (MoveKey2 ? "{" MoveKey2  " down}" : "")
	Sleep studs
	Send "{" MoveKey1  " up}" (MoveKey2 ? "{" MoveKey2  " up}" : "")
}
; Walk(studs, MoveKey1, MoveKey2:=0) {
; 	speed := 0.022
; 	sleepTime := studs / speed
; 	Send "{" MoveKey1  " down}" (MoveKey2 ? "{" MoveKey2  " down}" : "")
; 	Sleep sleepTime
; 	Send "{" MoveKey1  " up}" (MoveKey2 ? "{" MoveKey2  " up}" : "")
; }

CloseBrowserTab(){
    for hwnd in WinGetList(,, "Program Manager")
    {
        p := WinGetProcessName("ahk_id " hwnd)
        if (InStr(p, "Roblox") || InStr(p, "AutoHotkey"))
            continue ; skip roblox and AHK windows
        title := WinGetTitle("ahk_id " hwnd)
        if (title = "")
            continue ; skip empty title windows
        s := WinGetStyle("ahk_id " hwnd)
        if ((s & 0x8000000) || !(s & 0x10000000))
            continue ; skip NoActivate and invisible windows
        s := WinGetExStyle("ahk_id " hwnd)
        if ((s & 0x80) || (s & 0x40000) || (s & 0x8))
            continue ; skip ToolWindow and AlwaysOnTop windows
        try
        {
            WinActivate "ahk_id " hwnd
            WinMaximize("ahk_id " hwnd)
            Sleep 500
            Send "^{w}"
        }
        break
    }
}


CheckDisconnnect(){
    hwnd := GetRobloxHWND()
    GetRobloxClientPos()
    pBMScreen := Gdip_BitmapFromScreen(windowX "|" windowY + 30 "|" windowWidth "|" windowHeight - 30)
    if (Gdip_ImageSearch(pBMScreen, bitmaps["disconnected"], , , , , , 2) = 1 || GetRobloxHWND() == 0)  {
        PlayerStatus("Starting Grow A Garden 2", "0x00a838", ,false, ,false)    
        Gdip_DisposeImage(pBMScreen)
        CloseRoblox()
        PlaceID := 97598239454123

        linkCode := ""
        shareCode := ""
        VipLink := IniRead(settingsFile, "Settings", "VipLink","")

        if RegExMatch(VipLink, "privateServerLinkCode=(\d+)", &match)
            linkCode := match[1]
        else if RegExMatch(VipLink, "code=([a-f0-9]+)&type=Server", &match)
            shareCode := match[1]
        
        if linkCode {
        DeepLink := "roblox://placeID=" PlaceID "&linkCode=" linkCode
        } else if shareCode {
            DeepLink := "https://www.roblox.com/share?code=" shareCode "&type=Server"
        } else {
            DeepLink := "roblox://placeID=" PlaceID
        }
        try Run DeepLink

        loop 60 {
            if GetRobloxHWND() {
                Sleep(500)
                CloseBrowserTab()
                Sleep(500)
                ActivateRoblox()
                Sleep(500)
                ResizeRoblox()
                ActivateRoblox()
                GetRobloxClientPos(GetRobloxHWND())
                Sleep(25000) ; Game Loading Time here dynamiically would be perfect to check loading time.
                MouseMove windowX + windowWidth * 0.5, windowY + windowHeight * 0.5
                Sleep(500)
                Click
                Click
                PlayerStatus("Game Succesfully loaded", "0x00a838", ,false)
                Sleep(1000)
                CloseChat()
                Close_Leaderboard()
                Sleep(1500)
                return 1
            }
            Sleep(1000)
        }
        if (A_Index == 60){
            Sleep(500)
            CloseBrowserTab()
            Sleep(500)
        }
        Gdip_DisposeImage(pBMScreen)
        return 0

    } else {
        Gdip_DisposeImage(pBMScreen)
        return 0
    }
}

CloseChat(){
    ActivateRoblox()
    hwnd := GetRobloxHWND()
    GetRobloxClientPos(hwnd)
    pBMScreen := Gdip_BitmapFromScreen(windowX "|" windowY "|" windowWidth * 0.25 "|" windowHeight * 0.125)
    if (Gdip_ImageSearch(pBMScreen, bitmaps["ChatOpen"] , &OutputList, , , , , 25) = 1) {
        Cords := StrSplit(OutputList, ",")
        x := Cords[1] + windowX
        y := Cords[2] + windowY
        MouseMove(x, y)
        Sleep(300)
        Click
    }
    Gdip_DisposeImage(pBMScreen)
}



Close_Leaderboard(){
    ActivateRoblox()
    hwnd := GetRobloxHWND()
    GetRobloxClientPos(hwnd)
    capX := windowX + windowWidth - 300  
    capY := windowY                      
    capW := 300                          
    capH := 200                          
    pBMScreen := Gdip_BitmapFromScreen(capX "|" capY "|" capW "|" capH)
    if (Gdip_ImageSearch(pBMScreen, bitmaps["Leaderboard"], , , , , , 25) = 1) {
        Send("{Tab}")
        Sleep(100)
        Gdip_DisposeImage(pBMScreen)
        return true
    }
    Gdip_DisposeImage(pBMScreen)
    return false 
}



ChangeCamera(type){
    Send("{" EscKey "}")
    HyperSleep(1000)
    Open_Setting_Menu()
    HyperSleep(500)
    loop 10 {
        Send("{Up}")
        Sleep(50)
    }
    Sleep(150)
    
    Scroll_Until_CameraMode()

    HyperSleep(333)
    Send("{Right}")
    HyperSleep(333)
    Send("{Right}")
    HyperSleep(333)
    checkCamera(type)
    Send("{" EscKey "}")
    HyperSleep(1000)
}

Open_Setting_Menu(){
    ActivateRoblox()
    hwnd := GetRobloxHWND()
    GetRobloxClientPos(hwnd)
    pBMScreen := Gdip_BitmapFromScreen(windowX "|" windowY + 30 "|" windowWidth "|" windowHeight - 30)
    if (Gdip_ImageSearch(pBMScreen, bitmaps["SettingIcon"] , &OutputList, , , , , 25) = 1) {
        Cords := StrSplit(OutputList, ",")
        x := Cords[1] + windowX
        y := Cords[2] + windowY + 30
        MouseMove(x, y)
        Sleep(300)
        Click
    }
    Gdip_DisposeImage(pBMScreen)
}



Scroll_Until_CameraMode(){
    
    ActivateRoblox()
    hwnd := GetRobloxHWND()
    GetRobloxClientPos(hwnd)
    loop {
        pBMScreen := Gdip_BitmapFromScreen(windowX "|" windowY "|" windowWidth "|" windowHeight)
        if (Gdip_ImageSearch(pBMScreen, bitmaps["Camera Mode"] , , , , , , 25) = 1) {
            Gdip_DisposeImage(pBMScreen)
            return 1
        } else {
            Send("{Down}")
            Sleep(50)
            Gdip_DisposeImage(pBMScreen)
        }

        if A_Index == 25 {
            PlayerStatus("CRITICAL ERROR!!! Please dm me this error!", "0xffe100",,true,,true)
        }
    }
    
}



checkCamera(Camera_mode){  
    ActivateRoblox()
    hwnd := GetRobloxHWND()
    GetRobloxClientPos(hwnd)
    loop 8 {
        pBMScreen := Gdip_BitmapFromScreen(windowX "|" windowY "|" windowWidth "|" windowHeight)
        if (Gdip_ImageSearch(pBMScreen, bitmaps[Camera_mode] , , , , , , 25) = 1) {
            Gdip_DisposeImage(pBMScreen)
            return 1
        } else {
            Send("{Right}")
            Sleep(1000)
            Gdip_DisposeImage(pBMScreen)
        }
    }

}




ZoomAlign(){
    ActivateRoblox()
    relativeMouseMove(0.5,0.5)
    Loop 40 {
        Send("{WheelUp}")
        Sleep 20
    }

    Sleep(500)
    Loop 6 {
        Send("{WheelDown}")
        Sleep 50
    }
    Sleep(100)
    Click
    Sleep(250)
}


CameraCorrection(){
    Disconnect()
    Clickbutton_Tabs("Garden")
    ZoomAlign()
    Click("Right", "Down")
    Sleep(200)
    relativeMouseMove(0.5, 0.5)
    Sleep(200)
    MouseMove(0, 800, 10, "R")
    Sleep(200)
    Click("Right", "Up")
    Sleep(250)
    Clickbutton_Tabs("Seeds")

}

SpamClick(amount){
    loop amount {
        Click
        Sleep 20
    }
}

Close_Robux_Button(){
    ActivateRoblox()
    hwnd := GetRobloxHWND()
    GetRobloxClientPos(hwnd)
    capX := windowX + windowWidth * 0.25
    capY := windowY 
    pBMScreen := Gdip_BitmapFromScreen(capX "|" capY "|" windowWidth * 0.5 "|" windowHeight)
    if (Gdip_ImageSearch(pBMScreen, bitmaps["Robux"], &OutputList, , , , , 25) = 1) {
        Cords := StrSplit(OutputList, ",")
        x := Cords[1] + capX
        y := Cords[2] + capY 
        MouseMove(x, y)
        Sleep(300)
        Click
        Gdip_DisposeImage(pBMScreen)
        return 1
    }
    Gdip_DisposeImage(pBMScreen)
    return 0
}


RedX_Shop_Button(clickit := 1){
    ActivateRoblox()
    hwnd := GetRobloxHWND()
    GetRobloxClientPos(hwnd)
    capX := windowX + windowWidth * 0.6
    capY := windowY + windowHeight * 0.1
    capW := windowWidth * 0.2
    capH := windowHeight * 0.3
    pBMScreen := Gdip_BitmapFromScreen(capX "|" capY "|" capW "|" capH)
    if (Gdip_ImageSearch(pBMScreen, bitmaps["Xbutton"], &OutputList, , , , , 25) = 1 || Gdip_ImageSearch(pBMScreen, bitmaps["Xbutton2"], &OutputList, , , , , 25) = 1) {
        if (clickit == 1){
            Cords := StrSplit(OutputList, ",")
            x := Cords[1] + capX
            y := Cords[2] + capY
            MouseMove(x, y)
            Sleep(300)
            Click
        }
        return 1
    }
    Gdip_DisposeImage(pBMScreen)
    return 0
}




Clickbutton_Tabs(button, clickit := 1){
    hwnd := GetRobloxHWND()
    GetRobloxClientPos(hwnd)    
    
    capX := windowX + (windowWidth * 0.25)
    capY := windowY + 30
    capW := windowWidth * 0.5
    capH := 100
    varation := 20
    
    pBMScreen := Gdip_BitmapFromScreen(capX "|" capY "|" capW "|" capH)
    if (Gdip_ImageSearch(pBMScreen, bitmaps[button], &OutputList, , , , , varation) = 1) {
        if (clickit == 1){
            Cords := StrSplit(OutputList, ",")
            x := Cords[1] + windowX + (windowWidth * 0.25)
            y := Cords[2] + windowY + 30
            MouseMove(x, y)
            Sleep(300)
            Click
        }
        Gdip_DisposeImage(pBMScreen)
        return 1
    }
    Gdip_DisposeImage(pBMScreen)
    return 0
}





CheckStock(index, list){
    ActivateRoblox()
    hwnd := GetRobloxHWND()
    GetRobloxClientPos(hwnd)
    captureWidth := 150
    captureHeight := Integer(windowHeight * 0.5) + 100

    captureX := Integer(windowX + (windowWidth * 0.4))
    captureY := Integer(windowY + (windowHeight * 0.25))

    pBMScreen := Gdip_BitmapFromScreen(captureX "|" captureY "|" captureWidth "|" captureHeight)
    If !(Gdip_ImageSearch(pBMScreen, bitmaps["GreenStock"], &OutputList, , , , , 3,,3) = 1 || Gdip_ImageSearch(pBMScreen, bitmaps["GreenStock2"], &OutputList , , , , , 3,,3) = 1) {
        Gdip_DisposeImage(pBMScreen)
        return 0
    }

    loop {
        pBMScreen := Gdip_BitmapFromScreen(captureX "|" captureY "|" captureWidth "|" captureHeight)
        If (Gdip_ImageSearch(pBMScreen, bitmaps["GreenStock"], &OutputList, , , , , 3,,3) = 1 || Gdip_ImageSearch(pBMScreen, bitmaps["GreenStock2"], &OutputList , , , , , 3,,3) = 1) {
            Cords := StrSplit(OutputList, ",")
            x := Cords[1] + captureX - 5
            y := Cords[2] + captureY - 10
            MouseMove(x, y)
            SpamClick(15)
            Gdip_DisposeImage(pBMScreen)
            Sleep(150)
        } else {
            Gdip_DisposeImage(pBMScreen)
            PlayerStatus("Bought " list[index] "s!", "0x22e6a8",,false)
            return 1
        }

        if (A_index == 50) {
            Gdip_DisposeImage(pBMScreen)
            return 0
        }
    }

}






buyShop(itemList, itemType){
    ; It makes sure shop is ready to be looped through.
    pos := 0.85
    relativeMouseMove(0.4,pos)
    Loop itemList.length * 3 {
        Send("{WheelUp}")
        Sleep 20
    }
    Sleep(250)
    Click
    Sleep(250)
    Loop 12 {
        Send("{WheelUp}")
        Sleep 20
    }
    relativeMouseMove(0.5,0.4)
    Sleep(250)

    ; Ready for buying loop!

    for (item in itemlist){
        if A_Index == 1 {
            pos := 0.4
        } else {
            pos := 0.7
        }

        relativeMouseMove(0.4,pos)
        Click
        Sleep(350)

        if (CheckSetting(itemType, StrReplace(item, " ", ""))){
            CheckStock(A_Index, itemlist)
        } else {
            Sleep(200)
        }

    }
    CloseShop()
}




DetectShop(shop){
    loop 15 {
        Sleep(500)
        if (RedX_Shop_Button(0) == 1){
            Sleep(2500)
            PlayerStatus("Detected " shop " shop opened", "0x22e6a8",,false,,false)
            return 1
        }
    }
    PlayerStatus("Failed to open " shop " shop", "0x22e6a8",,false,,true)
    return 0
}


CloseShop(){
    loop 15 {
        Sleep(500)
        if (RedX_Shop_Button() == 1){
            Sleep(1000)
            PlayerStatus("Closed shop!", "0x22e6a8",,false,,false)
            return 1
        }
    }
    PlayerStatus("Failed to close shop.", "0xFF0000",,false,,true)
    return 0

}


CloseClutter(){
    RedX_Shop_Button()
    Sleep(200)
    Close_Robux_Button()
    Sleep(100)
}

getItems(item){
    static fileContent := ""

    if !fileContent {
        try {
            request := ComObject("WinHttp.WinHttpRequest.5.1")
            request.Open("GET", "https://raw.githubusercontent.com/epicisgood/GAG-2-Updater/refs/heads/main/items.json", true)
            request.Send()
            request.WaitForResponse()
            fileContent := JSON.parse(request.ResponseText)
            global MyWindow
            MyWindow.ExecuteScriptAsync("document.querySelector('#random-message').textContent = '" fileContent["message"] "'")
            
        } catch as e {
            PlayerStatus("This is a very rare error! " e.Message, "0xFF0000",,true,,false)
        }
    }
    names := []
    for itemObj in fileContent[item] {
        names.Push(itemObj["name"])
    }
    return names
    ; jsonData := fileContent
    ; return jsonData[item]
}

initShops(){
    static Shopinit := true
    static crateinit := true
    if (Shopinit == true){
        if (If_Minute(0) || If_Minute(5)) {
            global LastShopTime := nowUnix()
            BuySeeds()
            BuyGears()
            BuyCrates()
            Shopinit := false
        }
    } 


}

BuySeeds(){
    seedItems := getItems("Seeds")
    if !(CheckSetting("Seeds", "Seeds")){
        return
    }
    loop 3 {
        if (Disconnect()){
            Sleep(1500)
            CameraCorrection()
        }
        PlayerStatus("Going to buy Seeds!", "0x22e6a8",,false,,false)
        relativeMouseMove(0.5, 0.5)
        Sleep(500)
        Clickbutton_Tabs("Seeds")
        Sleep(1000)
        Send("{" Ekey "}")
        if !DetectShop("seed"){
            CameraCorrection()
            continue
        }
        buyShop(seedItems, "Seeds")
        CloseClutter()
        return 1
    }
    PlayerStatus("Failed to buy seeds 3 times, CLOSING ROBLOX!", "0x001a12")
    CloseRoblox()
    Sleep(1000)
    Disconnect()
    CameraCorrection()
}



BuyGears(){
    gearItems := getItems("Gears")
    if !(CheckSetting("Gears", "Gears")){
        return
    }
    loop 3 {
        PlayerStatus("Going to buy Gears!", "0x22e6a8",,false,,false)
        if (Disconnect()){
            Sleep(1500)
            CameraCorrection()
        }
        ActivateRoblox()
        Clickbutton_Tabs("Seeds")
        Sleep(1000)
        Walk(600,Skey)
        Walk(850,Akey)
        Sleep(1000)
        Send("{" Ekey "}")
        if !DetectShop("gear"){
            CameraCorrection()
            continue
        }
        buyShop(gearItems, "Gears")
        CloseClutter()
        return 1
    }
    
    CloseClutter()
    Sleep(1500)
    PlayerStatus("Failed to open gear shop 3 times.", "0x001a12")
    CloseRoblox()
    Sleep(1000)
    Disconnect()
    CameraCorrection()
}


BuyCrates(){
    if !(CheckSetting("Crates", "Crates")){
        return
    }
    crateitems := getItems("Crates")
    loop 3 {
        if (Disconnect()){
            Sleep(1500)
            CameraCorrection()
        }
        PlayerStatus("Going to buy Crates!", "0x22e6a8",,false,,false)
        ActivateRoblox()
        Clickbutton_Tabs("Seeds")
        Sleep(1000)
        Walk(2200,Skey)
        Walk(400,Akey)
        Sleep(1000)
        Send("{" Ekey "}")
        if !DetectShop("crate"){
            CameraCorrection()
            continue
        }
        buyShop(crateitems, "Crates")
        CloseClutter()
        return 1
    }
}




Disconnect(){
    loop 3 {
        if (CheckDisconnnect()){
            return 1
        }
    }
}

MainLoop() {

    if (GetRobloxHWND()){
        ResizeRoblox()
    }
    
    if (Disconnect()){
        Sleep(1500)
        return
    }

    MyWindow.Destroy()
    CloseChat() 
    Close_Leaderboard()
    CameraCorrection()
    BuySeeds()
    BuyGears()
    BuyCrates()
    loop {
        initShops()
        
        if (If_Minute(4) || If_Minute(9) && A_Sec == 30) {
            CameraCorrection()
        }
        if (If_Minute(0) || If_Minute(5)) {
            RewardInterupt()
        }

        if (If_Minute(3)){
            CloseClutter()
            Close_Leaderboard()
            if (Disconnect()){
                Sleep(1500)
                CameraCorrection()
            }
        }
        ShowToolTip()
        Sleep(1000)
    }
    
    
    
}


ShowToolTip(){
    global Shops

    currentTime := nowUnix()
    tooltipText := ""

    for _, shop in Shops.OwnProps() {
        enabled := IniRead(settingsFile, shop.name, shop.name) + 0
        if (!enabled)
            continue

        remaining := Max(0, shop.duration - (currentTime - shop.lastTime))
        tooltipText .= shop.name ": " (remaining // 60) ":" Format("{:02}", Mod(remaining, 60)) "`n"
    }

    ToolTip(tooltipText, 100, 100)
}



F2::
{
    ; ActivateRoblox()
    ; ResizeRoblox()
    ; hwnd := GetRobloxHWND()
    ; GetRobloxClientPos(hwnd)
    ; pBMScreen := Gdip_BitmapFromScreen(windowX "|" windowY + 30 "|" windowWidth "|" windowHeight - 30)
    ; Gdip_SaveBitmapToFile(pBMScreen,"ss.png")
    ; Gdip_DisposeImage(pBMScreen)
    PauseMacro()
}










