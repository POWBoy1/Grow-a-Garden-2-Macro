# 🍄 Epic's Grow A Garden 2 Macro

![GitHub Repo stars](https://img.shields.io/github/stars/epicisgood/Grow-a-Garden-2-Macro?style=flat)
![GitHub Downloads (all assets, all releases)](https://img.shields.io/github/downloads/epicisgood/Grow-a-Garden-2-Macro/total)
![GitHub Created At](https://img.shields.io/github/created-at/epicisgood/Grow-a-Garden-2-Macro)
![GitHub License](https://img.shields.io/github/license/epicisgood/Grow-a-Garden-2-Macro)


A macro for **Grow A Garden 2** that automatically buys your selected seeds, gears, and props and more!

✅ Supports **auto-reconnect** and sends **images via Discord webhook**.

✅ The macro does NOT require **UI navigation** and the macro works using your **cursor**.


<img width="600" height="400" alt="image" src="https://github.com/user-attachments/assets/b16adfff-afb8-48b1-8c41-5c774902263b" />


---

## 📥 Installation

1. **Download the Repository**

   * Visit the [Latest Release](https://github.com/epicisgood/Grow-a-Garden-2-Macro/releases/latest)
   * Download and **extract** the ZIP file

2. **Run the Macro**

   * Double-click `start.bat`

3. **Set Up Discord Webhook (Optional)**

   * [Find your User/Server/Message ID](https://support.discord.com/hc/en-us/articles/206346498)
   * [Set up a Discord Webhook](https://support.discord.com/hc/en-us/articles/228383668)

---

## ⌨️ Controls

| Action      | Key |
| ----------- | --- |
| Start Macro | F1  |
| Stop Macro  | F2  |
| Stop Macro | ``Alt`` ``S``  |
| Pause Macro | F3  |

---


## 📬 Contact

Need help extracting ZIPs or setting things up?

* **Discord Server:** [link](https://discord.com/invite/Vc465gUXHk)
* **Discord user:** [`_epic.`](https://discord.com/users/726162926851063919)
* **GitHub:** [epicisgood/Grow-a-Garden-2-Macro](https://github.com/epicisgood/Grow-a-Garden-2-Macro)
* **Donate:** [Give me Robux!](https://www.roblox.com/games/18130765440/Grow-a-Garden-Donation-Area#!/store)

---

🤑💵💸🐶


